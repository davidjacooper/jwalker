#!/usr/bin/python
print("Hello world")
